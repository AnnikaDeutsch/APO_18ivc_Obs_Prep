"""Makes TUIMenu into a package, so one can import subpackages"""
