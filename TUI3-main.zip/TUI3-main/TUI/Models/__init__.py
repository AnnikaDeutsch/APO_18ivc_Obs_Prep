"""Models a few common actors. Eventually all models will move here or at least be accessed from here.
"""
