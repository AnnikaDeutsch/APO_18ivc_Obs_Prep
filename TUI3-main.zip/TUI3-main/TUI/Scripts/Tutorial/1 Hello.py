def run(sr):
    """Trivial script"""
    sr.showMsg("Hello!")
    yield sr.waitMS(1000)
