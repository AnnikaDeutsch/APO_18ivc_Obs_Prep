"""Run a file of commands.

Each line must consist of the actor followed by the command, e.g.:
tcc show time

Blank lines and lines beginning with # are ignored.

To do:
- Fix resizing
- Support Run Selection and Run From Cursor

Also, if these are easy to figure out:
- Clear CurrCmdTag if user edits the file
- Add appropriate accelerator keys for Save and Open

History:
2006-03-10 ROwen
2010-03-10 ROwen    Bug fix: Save As was not working (tkFileDialog.asksaveasfile returns a file, not a path).
2014-07-01 ROwen       Copied Elena's "tui wait <timeSec>" support from STUI.
"""
import os
import tkinter
import RO.Wdg
import RO.CnvUtil
import tkinter.filedialog

HelpURL = "Scripts/BuiltInScripts/RunCommands.html"

CurrCmdTag = "currCmd"

class ScriptClass(object):
    def __init__(self, sr):
        self.filePath = None
    
        # make window resizable
        sr.master.winfo_toplevel().wm_resizable(True, True)
        
        # create widgets
        fileFrame = tkinter.Frame(sr.master)
        fileMenubutton = tkinter.Menubutton(
            fileFrame,
            text = "File",
            indicatoron = False,
            width = 4,
        )
        fileMenu = tkinter.Menu(fileMenubutton,
            tearoff = False,
        )
        fileMenubutton["menu"] = fileMenu
        fileMenu.add_command(
            label="Open...",
            command = self.doOpen,
        )
        fileMenu.add_command(
            label = "Save",
            command = self.doSave,
        )
        fileMenu.add_command(
            label = "Save As",
            command = self.doSaveAs,
        )
        fileMenubutton.pack(side="left")
        
        self.filePathWdg = RO.Wdg.StrEntry(
            master = fileFrame,
            readOnly = True,
            helpText = "current file",
        )
        self.filePathWdg.pack(side="left", expand=True, fill="x")
        fileFrame.grid(row=0, column=0, columnspan=2, sticky="ew")
        
        yscroll = tkinter.Scrollbar (
            master = sr.master,
            orient = "vertical",
        )
        self.textWdg = RO.Wdg.Text(
            sr.master,
            yscrollcommand = yscroll.set,
            width = 40,
            height = 10,
            #relief = "raised",
            #borderwidth = 1,
            helpText = "Commands to execute",
            helpURL = HelpURL,
        )
        
        # configure appearance of currently executing command
        self.textWdg.tag_configure(CurrCmdTag,
            relief = "raised",
            borderwidth = 1,
        )
#       yscroll.configure(command=self.textWdg.yview)
        self.textWdg.grid(row=1, column=0, sticky="nsew")
#       yscroll.grid(row=1, column=1, sticky="ns")
    
        sr.master.rowconfigure(1, weight=1)
        sr.master.columnconfigure(0, weight=1)
            
    def doOpen(self, wdg=None):
        filePath = tkinter.filedialog.askopenfilename(
    #       initialdir = None,
    #       initialfile = None,
            title = "File of commands",
        )
        if not filePath:
            return
    
        # handle case of filePath being a weird Tcl object
        self.filePath = RO.CnvUtil.asStr(filePath)
        
        fileObj = open(self.filePath, 'r')
        try:
            fileData = fileObj.read()
            if fileData[-1] != "\n":
                fileData = fileData + "\n"
        finally:
            fileObj.close()
        
        self.textWdg.delete("0.0", "end")
        self.textWdg.insert("0.0", fileData)
        self.textWdg.see("0.0")
        
        self.filePathWdg.set(filePath)
        overflow = len(filePath) - self.filePathWdg["width"]
        if overflow > 0:
            self.filePathWdg.xview(overflow)
    
    def doSave(self):
        if not self.filePath:
            self.doSaveAs()
            return
        
        data = self.getData()
        #outFile = file(self.filePath, 'w')
        outFile = open(self.filePath, 'w')
        try:
            outFile.write(data)
        finally:
            outFile.close()
    
    def doSaveAs(self):
        if self.filePath:
            currFileDir, currFileName = os.path.split(self.filePath)
        else:
            currFileDir = currFileName = None
        outFile = tkinter.filedialog.asksaveasfile(
            initialdir = currFileDir,
            initialfile = currFileName,
#           title = "File of commands",
        )
        if not outFile:
            return
        
        try:
            data = self.getData()
            outFile.write(data)
        finally:
            outFile.close()
        self.filePath = os.path.abspath(outFile.name)
        self.filePathWdg.set(self.filePath)
    
    def getData(self):
        """Return the current text"""
        return self.textWdg.get("0.0", "end")
    
    def run(self, sr):
        self.textWdg.focus_get()
        textStr = self.getData()
        if not textStr.isascii():
            raise sr.ScriptError(
                    "Non-ASCII character(s) detected in this run commands script."
                    )
        textList = textStr.split("\n")
        lineNum = 0
        for line in textList:
            lineNum += 1
            line = line.strip()
            if not line or line.startswith("#"):
                continue
        
            ind = "%d.0" % lineNum
            self.textWdg.tag_remove(CurrCmdTag, "0.0", "end")
            self.textWdg.tag_add(CurrCmdTag, ind, ind + " lineend")
            self.textWdg.see(ind)
            sr.showMsg("Executing: %s" % (line,))
            self.textWdg["state"] = "disabled"
            actor, cmdStr = line.split(None, 1)
            if actor.lower() != "tui":
                yield sr.waitCmd(
                    actor = actor,
                    cmdStr = cmdStr,
                )
            else:
                params = cmdStr.split()
                if len(params)==0:
                    raise sr.ScriptError("No tui command specified")
                
                if params[0].lower() == "wait":
                    if len(params) != 2:
                        raise sr.ScriptError("tui wait requires one parameter: time (in sec)")
                    waitSec = float(params[1])
                    yield sr.waitMS(waitSec * 1000)
                else: 
                    raise sr.ScriptError("Unreconized tui command: %r" % (cmdStr,))                 
    
    def end(self, sr):
        if not sr.didFail():
            self.textWdg.tag_remove(CurrCmdTag, "0.0", "end")
        
        self.textWdg["state"] = "normal"
