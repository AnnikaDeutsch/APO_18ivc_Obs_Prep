"""Miscellaneous widgets including (eventually) weather
and instant messaging"""
