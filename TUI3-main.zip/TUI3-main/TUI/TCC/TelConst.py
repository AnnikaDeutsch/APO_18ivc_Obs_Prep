Longitude = -105.820417 # longitude east, deg
Latitude  =   32.780361 # latitude north, deg
Elevation =    2.788    # elevation, km
