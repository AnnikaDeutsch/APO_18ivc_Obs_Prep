"""Offset widget"""
