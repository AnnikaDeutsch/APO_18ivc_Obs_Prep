#!/usr/bin/env python
"""Offset control.

History:
2003-04-04 ROwen
2003-04-15 ROwen    Bug fix: window could be resized.
2003-04-21 ROwen    Renamed StatusWdg to StatusBar to avoid conflicts.
2003-04-22 ROwen    Renamed from SimpleOffsetWdg to OffsetWdg
2003-06-09 ROwen    Removed most args from addWindow
                    and dispatcher and prefs args from OffsetWdg.
2003-06-12 ROwen    Added helpText entries.
2003-06-25 ROwen    Modified test case to handle message data as a dict
2003-11-06 ROwen    Changed Offset.html to OffsetWin.html
2003-11-19 ROwen    PR 8 fix: I changed slews to computed (in InputWdg)
                    but did not add timeLimKeyword="SlewDuration" to the KeyCommand,
                    so commands could time out.
2003-12-05 ROwen    Disable the Offset button during the offset.    
2004-02-23 ROwen    Modified to play cmdDone/cmdFailed for commands.
2004-05-18 ROwen    Eliminated redundant import in test code.
2004-06-22 ROwen    Modified for RO.Keyvariable.KeyCommand->CmdVar
2005-01-05 ROwen    Changed level to severity for RO.Wdg.StatusBar.
2005-08-02 ROwen    Modified for TUI.Sounds->TUI.PlaySound.
2010-11-03 ROwen    Stopped using anchors within the HTML help file.
2011-06-17 ROwen    Changed "type" to "msgType" in parsed message dictionaries (in test code only).
"""
import tkinter
import RO.Constants
import RO.Wdg
from . import InputWdg
import TUI.TUIModel
import TUI.PlaySound

WindowName = "TCC.Offset"
_HelpURL = "Telescope/OffsetWin.html"

def addWindow(tlSet):
    """Create the window for TUI.
    """
    tlSet.createToplevel(
        name = WindowName,
        defGeom = "+0+507",
        resizable = False,
        wdgFunc = OffsetWdg,
    )

class OffsetWdg(tkinter.Frame):
    def __init__ (self,
        master = None,
     **kargs):
        """creates a new widget for specifying simple offsets

        Inputs:
        - master        master Tk widget -- typically a frame or window
        """
        tkinter.Frame.__init__(self, master, **kargs)

        self.inputWdg = InputWdg.InputWdg(self)
        self.inputWdg.pack(side="top", anchor="nw")
        self.inputWdg.addCallback(self._offsetEnable)
        
        tuiModel = TUI.TUIModel.getModel()

        # set up the command monitor
        self.statusBar = RO.Wdg.StatusBar(
            master = self,
            dispatcher = tuiModel.dispatcher,
            prefs = tuiModel.prefs,
            playCmdSounds = True,
            helpURL = _HelpURL,
        )
        self.statusBar.pack(side="top", anchor="nw", expand="yes", fill="x")
        
        # command buttons
        self.buttonFrame = tkinter.Frame(self)
        self.offsetButton = RO.Wdg.Button(
            master=self.buttonFrame,
            text="Offset",
            command=self.doOffset,
            helpText = "Offset the telescope",
            helpURL=_HelpURL,
        )
        self.offsetButton.pack(side="left")

        self.clearButton = RO.Wdg.Button(
            master=self.buttonFrame,
            text="Clear",
            command=self.inputWdg.clear,
            helpText = "Clear the displayed values",
            helpURL=_HelpURL,
        )
        self.clearButton.pack(side="left")

        def restoreOffset(name, valueDict):
            """Restore an offset from the history menu"""
            self.inputWdg.setValueDict(valueDict)

        self.historyMenu = RO.Wdg.HistoryMenu(
            master = self.buttonFrame,
            callFunc = restoreOffset,
            removeAllDup = True,
            helpText = "A list of past offsets",
            helpURL = _HelpURL,
        )
        self.historyMenu.pack(side="left")

        self.buttonFrame.pack(side="top", anchor="nw")
    
    def cmdSummary(self, valueDict):
        """Returns a short string describing a dictionary of settings.
        """
        typeStr = valueDict["type"].replace(" ", "_")
        amt =  valueDict["amount"]
        amt = [val or "0" for val in amt]
        amtStr = ', '.join(amt)
        return "%s %s %s" % (typeStr, amtStr, valueDict["absOrRel"])

    def addCmdToHistory(self):
        """Add the current settings to the history menu.
        """
        valueDict = self.inputWdg.getValueDict()
        self.historyMenu.addItem(self.cmdSummary(valueDict), valueDict)
        
    def doOffset(self):
        """Perform the offset.
        """
        self.inputWdg.neatenDisplay()
        self._offsetEnable(False)
        try:
            cmdStr = self.inputWdg.getCommand()
        except ValueError as e:
            self.statusBar.setMsg(
                "Rejected: %s" % e,
                severity = RO.Constants.sevError,
                isTemp = True,
            )
            TUI.PlaySound.cmdFailed()
            return

        def offsetEnableShim(*args, **kargs):
            self._offsetEnable(True)
            
        cmdVar = RO.KeyVariable.CmdVar (
            actor = "tcc",
            cmdStr = cmdStr,
            timeLim = 10,
            timeLimKeyword="SlewDuration",
            isRefresh = False,
            callFunc = offsetEnableShim,
        )
        self.statusBar.doCmd(cmdVar)
        self.addCmdToHistory()
    
    def _offsetEnable(self, doEnable=True):
        """Enables or disables the Apply button
        """
        if doEnable:
            self.offsetButton["state"] = "normal"
        else:
            self.offsetButton["state"] = "disabled"

if __name__ == "__main__":
    root = RO.Wdg.PythonTk()

    kd = TUI.TUIModel.getModel(True).dispatcher

    testFrame = OffsetWdg(root)
    testFrame.pack(anchor="nw")

    dataDict = {
        "ObjInstAng": (30.0, 0.0, 1.0),
    }
    msgDict = {"cmdr":"me", "cmdID":11, "actor":"tcc", "msgType":":", "data":dataDict}
#   kd.dispatch(msgDict)

    root.mainloop()
