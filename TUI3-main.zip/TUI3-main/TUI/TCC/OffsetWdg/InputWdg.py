#!/usr/bin/env python
"""Simple offset control.
Allows changing the boresight position
or setting the arc offset in inst xy.

History:
2003-04-02 ROwen
2003-04-14 ROwen    Renamed Sky->Object XY; added Object.
2003-06-09 Rowen    Removed dispatcher arg.
2003-06-11 ROwen    Modified to use new tccModel.objSys
2003-06-12 ROwen    Added helpText entries.
2003-06-17 ROwen    Reordered abs and rel to match Remark.
2003-06-25 ROwen    Modified test case to handle message data as a dict.
2003-07-10 ROwen    Modified to use overhauled RO.InputCont.
2003-10-14 ROwen    Modified to use computed offsets (by APO request).
2003-11-06 ROwen    Changed Offset.html to OffsetWin.html
2006-04-14 ROwen    Added explicit default to absOrRelWdg (required
                    due to recent changes in RO.Wdg.RadiobuttonSet).
2010-11-03 ROwen    Renamed Object to Object Arc
2011-06-17 ROwen    Changed "type" to "msgType" in parsed message dictionaries (in test code only).
"""
import tkinter
import RO.CoordSys
import RO.InputCont
import RO.StringUtil
import RO.Wdg
import TUI.TCC.TCCModel

_HelpURL = "Telescope/OffsetWin.html"
_MaxOffset = 3600 # arcsec

class InputWdg(RO.Wdg.InputContFrame):
    def __init__ (self,
        master = None,
     **kargs):
        """creates a new widget for specifying simple offsets

        Inputs:
        - master        master Tk widget -- typically a frame or window
        """
        RO.Wdg.InputContFrame.__init__(self, master, **kargs)
        self.tccModel = TUI.TCC.TCCModel.getModel()
        gr = RO.Wdg.Gridder(self, sticky="w")
        self.userLabels = ("RA", "Dec")
        
        # offset type
        self.offTypeWdg = RO.Wdg.OptionMenu (
            self,
            items = (
                "Object Arc",
                "Object Arc XY",
                None,
                "Boresight"
            ),
            defValue = "Object Arc",
            callFunc = self._offTypeChanged,
            helpText = (
                "object offset",
                "object offset in inst. x,y",
                None,
                "boresight offset",
            ),
            helpURL = _HelpURL,
        )
        gr.gridWdg (
            label = "Type",
            dataWdg = self.offTypeWdg,
            colSpan = 2,
        )
        lastCol = gr.getNextCol()-1
        self.columnconfigure(lastCol, weight=1)
        
        # position entry: use relative DMS entry fields
        self.offWdgSet = [None, None]
        self.offLabelSet = [None, None]
        for ii in range(2):
            unitsVar = tkinter.StringVar()
            wdg = RO.Wdg.DMSEntry(self,
                    minValue = -_MaxOffset,
                    maxValue = _MaxOffset,
                    defValue = None,
                    isHours = False,
                    isRelative = True,
                    helpText = "Amount of offset",
                    helpURL = _HelpURL,
                    unitsVar = unitsVar,
            )
            label = tkinter.Label(self, width=6, anchor="e")
            self.offWdgSet[ii] = wdg
            self.offLabelSet[ii] = label
            gr.gridWdg(
                label = label,
                dataWdg = wdg,
                units = wdg.unitsVar,
            )
    
        # relative or absolute
        frame = tkinter.Frame(self)
        self.absOrRelWdg = RO.Wdg.RadiobuttonSet (
            frame,
            textList = ("Abs", "Rel"),
            defValue = "Rel",
            side = "left",
            helpText = (
                "Replace the existing offset",
                "Add amount to existing offset",
            ),
            helpURL = _HelpURL,
        )
        gr.gridWdg (
            dataWdg = frame,
            colSpan = 3,
        )
        
        self.tccModel.objSys.addIndexedCallback(self._objSysChanged, 0)

        # create a set of input widget containers
        # this makes it easy to retrieve a command
        # and also to get and set all data using a value dictionary
        def formatCmd(inputCont):
            valDict = inputCont.getValueDict()
            offType = valDict["type"]
            offAmt = valDict["amount"]
            relOrAbs = valDict["absOrRel"]

            def arcSecToDeg(str):
                if not str:
                    return 0.0
                return RO.StringUtil.secFromDMSStr(str) / 3600.0
            offAmt = [arcSecToDeg(amtStr) for amtStr in offAmt]
    
            if offType == "Object Arc XY":
                offAmt = self._objFromInst(offAmt)
            tccType = {
                "Object Arc":"arc",
                "Object Arc XY":"arc",
                "Boresight":"boresight",
            }[offType]
    
            if relOrAbs == "Abs":
                relStr = "/pabs"
            else:
                relStr = ""
            return "offset %s %.7f, %.7f%s/computed" % (tccType, offAmt[0], offAmt[1], relStr)
        
        self.inputCont = RO.InputCont.ContList (
            conts = [
                RO.InputCont.WdgCont (
                    name = "type",
                    wdgs = self.offTypeWdg,
                    omitDef = False,
                ),
                RO.InputCont.WdgCont (
                    name = "amount",
                    wdgs = self.offWdgSet,
                    omitDef = False,
                ),                  
                RO.InputCont.WdgCont (
                    name = "absOrRel",
                    wdgs = self.absOrRelWdg,
                    omitDef = False,
                ),
            ],
            formatFunc = formatCmd,
        )

        # initialize display
        self.restoreDefault()
    
    def _offTypeChanged(self, *args):
        offType = self.offTypeWdg.getString()
        if offType == "Object Arc":
            offLabels = self.userLabels
        else:
            offLabels = ("Inst X", "Inst Y")
        for ii in range(2):
            self.offLabelSet[ii]["text"] = offLabels[ii]
    
    def _objSysChanged (self, csysObj, *args, **kargs):
        """Updates the display when the coordinate system is changed.
        """
        self.userLabels = csysObj.posLabels()
        
        self._offTypeChanged()
    
    def _objFromInst(self, offVec):
        """Rotates objPos from inst to obj coords.
        Raises ValueError if cannot compute.
        """
        objInstAngPVT, isCurrent = self.tccModel.objInstAng.getInd(0)
        objInstAng = objInstAngPVT.getPos()
        if not isCurrent or objInstAng is None:
            raise ValueError("objInstAng unknown")
        if None in offVec:
            raise ValueError("bug: unknown offset")
        return RO.MathUtil.rot2D(offVec, -objInstAng)
    
    def clear(self):
        for wdg in self.offWdgSet:
            wdg.set("")

    def getCommand(self):
        return self.getString()
            
    def neatenDisplay(self):
        for wdg in self.offWdgSet:
            wdg.neatenDisplay()


if __name__ == "__main__":
    import TUI.TUIModel

    root = RO.Wdg.PythonTk()

    kd = TUI.TUIModel.getModel(True).dispatcher

    testFrame = InputWdg(root)
    testFrame.pack(anchor="nw")

    dataDict = {
        "ObjInstAng": (30.0, 0.0, 1.0),
    }
    msgDict = {"cmdr":"me", "cmdID":11, "actor":"tcc", "msgType":":", "data":dataDict}
    kd.dispatch(msgDict)
    
    def doPrint():
        print(testFrame.getCommand())
        
    def doSummary():
        print(testFrame.getSummary())
    
    def defaultCommand():
        testFrame.restoreDefault()

    buttonFrame = tkinter.Frame(root)
    tkinter.Button (buttonFrame, command=doPrint, text="Print").pack(side="left")
    tkinter.Button (buttonFrame, command=doSummary, text="Summary").pack(side="left")
    tkinter.Button (buttonFrame, command=defaultCommand, text="Default").pack(side="left")
    tkinter.Button (buttonFrame, command=testFrame.neatenDisplay, text="Neaten").pack(side="left")
    buttonFrame.pack()

    root.mainloop()
