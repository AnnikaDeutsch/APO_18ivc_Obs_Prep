""" Widget for displaying telescope status """
