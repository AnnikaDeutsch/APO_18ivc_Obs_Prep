"""Catalog of user objects"""
from .CatalogMenuWdg import *
