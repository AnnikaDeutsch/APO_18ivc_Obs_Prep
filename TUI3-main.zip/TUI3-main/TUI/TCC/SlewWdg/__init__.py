""" widget for specifying a new object position """
