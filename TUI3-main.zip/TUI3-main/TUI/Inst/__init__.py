"""Widgets for various instruments"""
