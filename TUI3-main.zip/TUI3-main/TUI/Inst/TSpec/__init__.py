"""Dual Imaging Spectrograph"""
