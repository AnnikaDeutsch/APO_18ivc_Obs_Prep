"""ARCTIC Imager"""
