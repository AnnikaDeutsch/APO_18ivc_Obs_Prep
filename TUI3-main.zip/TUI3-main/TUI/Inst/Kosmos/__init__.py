"""Kosmos Spectrograph"""
