VersionStr = "3.2.0 2025-09-30"
VersionName, VersionDate = VersionStr.split()
ApplicationName = "TUI"
